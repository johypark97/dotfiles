-- =========================
-- -------- null-ls --------
-- =========================

return {
    'jose-elias-alvarez/null-ls.nvim',
    requires = { 'nvim-lua/plenary.nvim' },
}
