-- ========================
-- -------- tagbar --------
-- ========================

-- requirements: ctags

return {
    'majutsushi/tagbar',
    cmd = 'Tagbar',
}
