-- ==============================
-- -------- vim-dispatch --------
-- ==============================

return {
    'tpope/vim-dispatch',
    config = function()
        vim.g.dispatch_no_maps = 1
    end,
}
