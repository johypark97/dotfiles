-- ===================================
-- -------- nvim-lsp-ts-utils --------
-- ===================================

return {
    'jose-elias-alvarez/nvim-lsp-ts-utils',
    requires = {
        { 'neovim/nvim-lspconfig' },
        { 'nvim-lua/plenary.nvim' },
    },
}
