-- ====================================
-- -------- nvim-lsp-installer --------
-- ====================================

return 'williamboman/nvim-lsp-installer'
