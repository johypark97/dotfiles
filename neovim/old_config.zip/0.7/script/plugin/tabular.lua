-- =========================
-- -------- tabular --------
-- =========================

return {
    'godlygeek/tabular',
    cmd = 'Tabularize',
}
